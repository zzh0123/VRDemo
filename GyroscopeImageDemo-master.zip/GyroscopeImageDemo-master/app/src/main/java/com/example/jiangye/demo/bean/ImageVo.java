package com.example.jiangye.demo.bean;

/**
 * 创建时间: 2018/03/12 21:55 <br>
 * 作者: jiangye <br>
 * 描述:
 */

public class ImageVo {

  public String mImageUrl;

  public String mImageName;

  public ImageVo(String imageUrl, String imageName) {
    mImageUrl = imageUrl;
    mImageName = imageName;
  }
}
